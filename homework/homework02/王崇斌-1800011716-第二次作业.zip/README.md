### 计算物理第二次作业 绝热不变量

报告pdf文件的编译：Windows环境 `compile_latex.bat` 需要安装latexmk

报告文件`main.pdf`, 对应latex文件`main.tex`

需要使用到的算法和具体实现的代码参见`1_D_optimize.h`, `1_D_optimize.cpp`, `integral.h`, `integral.cpp`

每一问的程序以相应的题号开头命名

1.  `1_boundary.py`
2. `2_trajectory.cpp`, `2_plot_trajectory.py`, 编译脚本`compile2.bat`
3.  `3_trajectory.cpp`, `3_plot_trajectory.py`, 编译脚本`compile3.bat`
4. &5 `4_berry_phase.cpp`, 需要手动修改输入参数, 编译脚本`compile4.py`, `compile5.py`; `4_cal_time.cpp`可以直接在调试模式下运行, 没有写编译脚本; `4_plot.py`



